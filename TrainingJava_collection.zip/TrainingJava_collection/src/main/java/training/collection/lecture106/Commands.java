package training.collection.lecture106;

public enum Commands {
    GOWEST, RUNSOUTH,EAST;
}
