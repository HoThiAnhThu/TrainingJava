package training.collection.lecture106;

public class Location {
    public Location(int south, int west, int east) {
        this.south = south;
        this.west = west;
        this.east = east;
    }

    public void setSouth(int south) {
        this.south = south;
    }

    public void setWest(int west) {
        this.west = west;
    }

    public void setEast(int east) {
        this.east = east;
    }

    public int getSouth() {
        return south;
    }

    public int getWest() {
        return west;
    }

    public int getEast() {
        return east;
    }

    private int south;

    public Location() {
    }

    private int west;
    private int east;
}
