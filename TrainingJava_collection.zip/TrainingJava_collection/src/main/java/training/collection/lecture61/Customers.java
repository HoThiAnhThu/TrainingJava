package training.collection.lecture61;

import java.util.ArrayList;

public class Customers {
    private String name;

    public Customers() {
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDoubles(ArrayList<Double> doubles) {
        this.doubles = doubles;
    }

    public String getName() {
        return name;
    }

    public ArrayList<Double> getDoubles() {
        return doubles;
    }

    public Customers(String name, ArrayList<Double> doubles) {
        this.name = name;
        this.doubles = doubles;
    }

    private ArrayList<Double> doubles;
}
