package training.collection.lecture61;

import java.util.ArrayList;

public class Bank {
    public Bank() {
    }

    public Bank(ArrayList<Branch> listBranch) {
        this.listBranch = listBranch;
    }

    public void setListBranches(ArrayList<Branch> listBranch) {
        this.listBranch = listBranch;
    }

    public ArrayList<Branch> getListBranches() {
        return listBranch;
    }

    private ArrayList<Branch> listBranch;

    public ArrayList<Branch> addBranch(Branch branch) {
        listBranch.add(branch);
        return listBranch;
    }

    public static void main(String[] argv) {
        ArrayList<Branch> listBranch = new ArrayList<>();
        ArrayList<Customers> listCustomer = new ArrayList<>();
        ArrayList<Double> listDouble = new ArrayList<>();
        double numberDouble = 10.10;
        listDouble.add(numberDouble);
        Customers customers = new Customers();
        customers.setName("hthu");
        customers.setDoubles(listDouble);
        listCustomer.add(customers);
        Bank bank = new Bank(listBranch);
        Branch branch = new Branch(listCustomer);
        bank.addBranch(branch);
        listBranch = bank.addBranch(branch);
        for (Branch branches : listBranch) {
            listCustomer = branches.getListCustomer();
        }
        System.out.println(listCustomer.iterator().next().getName());
        System.out.println(listCustomer.iterator().next().getDoubles());

        listCustomer = branch.addCustomer(customers);
        for (Customers customer : listCustomer) {
            System.out.println(customer.getName());
            System.out.println(customer.getDoubles());
        }
    }
}
