package training.collection.lecture61;

import java.util.ArrayList;

public class Branch {
    public Branch() {
    }

    public Branch(ArrayList<Customers> listCustomer) {

        this.listCustomer = listCustomer;
    }

    public void setListCustomer(ArrayList<Customers> listCustomer) {
        this.listCustomer = listCustomer;
    }

    public ArrayList<Customers> getListCustomer() {
        return listCustomer;
    }

    private ArrayList<Customers> listCustomer;

    public ArrayList<Customers> addCustomer(Customers customers) {
        listCustomer.add(customers);
        return listCustomer;
    }
}
