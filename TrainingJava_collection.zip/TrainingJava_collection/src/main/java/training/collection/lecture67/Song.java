package training.collection.lecture67;

public class Song {
    private String title;
    private float duration;

    public Song(String title, float duration) {
        this.title = title;
        this.duration = duration;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDuration(float duration) {
        this.duration = duration;
    }

    public String getTitle() {
        return title;
    }

    public float getDuration() {
        return duration;
    }

    public Song() {
    }

    public Song quit() {
        return null;
    }

    public Song replay(Song song, float duration) {
        song.setDuration(duration);
        return song;
    }
}
