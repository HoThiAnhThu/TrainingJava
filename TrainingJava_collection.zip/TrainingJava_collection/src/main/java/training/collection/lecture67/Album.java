package training.collection.lecture67;

import java.util.ArrayList;
import java.util.Iterator;

public class Album {

    public Album() {
    }

    public Album(ArrayList<Song> listSong) {
        this.listSong = listSong;
    }

    public void setListSong(ArrayList<Song> listSong) {
        this.listSong = listSong;
    }

    public ArrayList<Song> getListSong() {
        return listSong;
    }

    private ArrayList<Song> listSong;

    public void skipNextSong(Album album) {

        Iterator<Song> song = album.getListSong().iterator();
        System.out.println(song.next().getTitle());
        System.out.println(song.next().getDuration());
    }

    public static void main(String[] argv) {

        Song song = new Song("hello", 0.2f);
        ArrayList<Song> listSong = new ArrayList<>();
        listSong.add(song);
        listSong.add(new Song("abc", 2.6f));
        listSong.add(new Song("djfn", 5.6f));
        Album album = new Album();
        album.setListSong(listSong);
        album.skipNextSong(album);
    }
}
