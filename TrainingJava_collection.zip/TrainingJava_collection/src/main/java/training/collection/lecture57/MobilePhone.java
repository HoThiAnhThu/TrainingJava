package training.collection.lecture57;

import java.util.ArrayList;

public class MobilePhone {
    public MobilePhone() {
    }

    private ArrayList<Contacts> listContacts;

    public MobilePhone(ArrayList<Contacts> listContacts) {
        this.listContacts = listContacts;
    }

    public void setListContacts(ArrayList<Contacts> listContacts) {
        this.listContacts = listContacts;
    }

    public ArrayList<Contacts> getListContacts() {
        return listContacts;
    }

    public ArrayList<Contacts> addContacts(String name, String phoneNumber) {
        Contacts contacts = new Contacts(name, phoneNumber);
        listContacts.add(contacts);
        return listContacts;
    }

    public ArrayList<Contacts> deleteContact(String name) {

        for (Contacts contact : listContacts) {
            if (contact.getName().equals(name)) {
                listContacts.remove(contact);
            }
        }
        return listContacts;
    }

    public ArrayList<Contacts> updateContact(String name, String phoneNumber) {

        for (Contacts contact : listContacts) {
            if (contact.getName().equals(name)) {
                contact.setName("hthu_test");
                contact.setPhoneNumber(phoneNumber);
            }
        }
        return listContacts;
    }

    public static void main(String[] argv) {

        ArrayList<Contacts> listContacts = new ArrayList<>();
        MobilePhone mobilePhone = new MobilePhone(listContacts);
        Contacts contacts = new Contacts();
        contacts.setName("abc");
        contacts.setPhoneNumber("123456");
        listContacts.add(contacts);
        listContacts = mobilePhone.getListContacts();

        System.out.println("List Contacts");
        for (Contacts contact : listContacts) {
            System.out.println(contact.getName());
            System.out.println(contact.getPhoneNumber());
        }

        listContacts = mobilePhone.addContacts("hthu", "123456");
        System.out.println("Add Contacts");
        for (Contacts contact : listContacts) {
            System.out.println(contact.getName());
            System.out.println(contact.getPhoneNumber());
        }

        listContacts = mobilePhone.deleteContact("abc");
        System.out.println("Delete Contacts");
        for (Contacts contact : listContacts) {
            System.out.println(contact.getName());
            System.out.println(contact.getPhoneNumber());
        }

        listContacts = mobilePhone.updateContact("hthu", "17956466");
        System.out.println("Update Contacts");
        for (Contacts contact : listContacts) {
            System.out.println(contact.getName());
            System.out.println(contact.getPhoneNumber());
        }
    }
}
