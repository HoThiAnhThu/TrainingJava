/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import entity.Book;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
import util.MyList;
import util.Node;

/**
 * @author TrongDuyDao
 */
public class BookList {

    LinkedList<Book> listBook = new LinkedList<>();
    //a list of book
    private MyList books;

    public MyList getBooks() {
        return books;
    }

    public BookList() {
        books = new MyList();
    }

    //1.0 accept information of a Book
    private Book getBook() {

        System.out.println("Nhap ma sach");
        Scanner book = new Scanner(System.in);
        int bcode = book.nextInt();
        if (bcode <= 0) {
            System.out.println("Vui long nhap lai ma sach");
            bcode = book.nextInt();
        }
        System.out.println("Nhap title");
        String titleBook = book.next();
        System.out.println("Nhap quantity");
        int quantityBook = book.nextInt();
        System.out.println("Nhap lended");
        int lend = book.nextInt();
        System.out.println("Nhap price");
        double priceBook = book.nextDouble();
        String masach = String.valueOf(bcode);
        Book books = new Book(masach, titleBook, quantityBook, lend, priceBook);
        return books;
    }

    //1.1 accept and add a new Book to the end of book list
    public void addLast() {
        Book book = getBook();
        Node<Book> node = new Node(book);
        books.addLast(book);
        if (listBook.isEmpty()) {
            listBook.addLast(node.info);
        } else {
            if (listBook.iterator().next().getbCode().equals(book.getbCode())) {
                getBook();
            } else {
                node = new Node(book);
                listBook.addLast(node.info);
            }
        }
    }

    //1.2 output information of book list
    public void list() {
        Iterator<Book> iterator = listBook.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }

    //1.3 search book by book code
    public void search() {

        Iterator<Book> iterator = listBook.iterator();
        if (books.search(iterator.next().getbCode()) == null) {
            System.out.println("search not found");
        }
        System.out.println("book code exist linked list");
    }

    //1.4 accept and add a new Book to the begining of book list
    public void addFirst() {

        Book book = getBook();
        Node<Book> node = new Node(book);
        books.addFirst(book);
        if (listBook.isEmpty()) {
            listBook.addFirst(node.info);
        } else {
            if (listBook.iterator().next().getbCode().equals(book.getbCode())) {
                getBook();
            } else {
                node = new Node(book);
                listBook.addFirst(node.info);
            }
        }
    }

    //1.5 Add a new Book after a position k
    public void addAfter() {

        Book book = getBook();
        Node<Book> node = new Node(book);
        int position = 1;
        if (listBook.iterator().next().getbCode().equals(book.getbCode())) {
            getBook();
        } else {
            node = new Node(book);
            listBook.add(position, book);
        }
    }

    //1.6 Delete a Book at position k
    public void deleteAt() {
        int position = 1;
        listBook.remove(position);
    }
}
