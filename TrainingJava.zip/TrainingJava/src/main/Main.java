/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;

/**
 * @author TrongDuyDao
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("Book List");
        System.out.println("1. Input book and add to the end");
        System.out.println("2. Display book");
        System.out.println("3. Search by code");
        System.out.println("4. Input book and add to begining");
        System.out.println("5. Add book after position");
        System.out.println("6. Delete book at position");
        System.out.println("7. Exit ");
        BookList bookList = new BookList();
        boolean check = true;
        do {
            Scanner input = new Scanner(System.in);
            System.out.println("Input number");
            int chon = input.nextInt();
            switch (chon) {
                case 1:
                    bookList.addLast();
                    break;
                case 2:
                    bookList.list();
                    break;
                case 3:
                    bookList.search();
                    break;
                case 4:
                    bookList.addFirst();
                    break;
                case 5:
                    bookList.addAfter();
                    break;
                case 6:
                    bookList.deleteAt();
                    break;
                case 7:
                    check = false;
                    break;
            }
        } while (check);
    }
}
